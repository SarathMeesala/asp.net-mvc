﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using phonebook.Models;

namespace phonebook.Controllers
{
    public class contactController : Controller
    {
        // GET: contact
        masterEntities entities = new masterEntities();
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(contact b)
        {
            entities.contacts.Add(b);
            entities.SaveChanges();
            ViewBag.Message = "contact added";
            return View(b);

        }
        public ActionResult Delete(int? id)
        {

            contact contact = entities.contacts.Find(id);

            return View(contact);
        }
        // POST: contacts/Delete/5
        [HttpPost]
        public ActionResult Delete(int id)
        {
            contact contact = entities.contacts.Find(id);
            entities.contacts.Remove(contact);
            entities.SaveChanges();
            return RedirectToAction("Details");

        }
        public ActionResult Details()
        {
            return View(entities.contacts.ToList());
        }
    }
}

